مشروع الحساب الذكي V13 - Android WebView

يحتوي هذا المشروع على واجهة V13 داخل assets وعلى إعداد GitHub Actions لبناء APK.

لبناء APK:
1) ارفع محتويات هذا المشروع إلى جذر مستودع GitHub (وليس ملف ZIP نفسه).
2) افتح تبويب Actions.
3) اختر Build Android APK ثم Run workflow.
4) بعد نجاح المهمة، افتح تفاصيل التشغيل ونزّل Artifact باسم alhesab-thaki-v13-debug-apk.

ملاحظة: هذا إصدار تجريبي Debug للتثبيت والاختبار، وليس إصدارًا موقّعًا للنشر في Google Play.
